export default function GuestLayout({ children }) {
    return (
        <>
            {children}
        </>
    );
}
