<!DOCTYPE html>
<html lang="en">

	<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Base Tempelate</title>
    <meta name="author" content="Sterco Digitex">

	<?php if($page->sections): ?>
			<?php $__currentLoopData = $page->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($section->css_styles): ?>
							<style>
									<?php echo $section->css_styles; ?>

							</style>
					<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endif; ?>
  </head>

	<body>
		<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<!-- Main Content -->
		<main class="main">
			<?php echo $renderedHtml; ?>

		</main>

		<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<!-- Include section-specific JavaScript -->
		<?php if($page->sections): ?>
			<?php $__currentLoopData = $page->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($section->javascript): ?>
					<script>
						<?php echo $section->javascript; ?>

					</script>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>
	</body>
</html><?php /**PATH D:\wamp\www\cms-base-template\core\resources\views/pages/show.blade.php ENDPATH**/ ?>